
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ησσвмαѕтєя | WebTV</title>
    
        <!-- Favicon and Apple Touch Icons -->
        <link rel="apple-touch-icon" sizes="57x57" href="https://noobmaster.xyz/logos/logo_57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="https://noobmaster.xyz/logos/logo_60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="https://noobmaster.xyz/logos/logo_72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="https://noobmaster.xyz/logos/logo_76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="https://noobmaster.xyz/logos/logo_114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="https://noobmaster.xyz/logos/logo_120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="https://noobmaster.xyz/logos/logo_144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="https://noobmaster.xyz/logos/logo_152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="https://noobmaster.xyz/logos/logo_180x180.png">
        <link rel="icon" type="image/png" sizes="192x192" href="https://noobmaster.xyz/logos/logo_192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="https://noobmaster.xyz/logos/logo_32x32.png">
        <link rel="icon" type="image/png" sizes="96x96" href="https://noobmaster.xyz/logos/logo_96x96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="https://noobmaster.xyz/logos/logo_16x16.png">

    
    <!-- Other styles -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="site-logo">
                <a href="index.php">
                    <img src="assets/webtvlogo.png" alt="ησσвмαѕтєя Channels" class="header-logo">
                </a>
            </div>
            <input type="text" id="searchInput" placeholder="Search channels...">
            
            <div class="categories">
                <a href="?category=all" class="active">All</a>
                                    <a href="?category=Entertainments" 
                       class="">
                        Entertainments                    </a>
                                    <a href="?category=Hindi+Movies" 
                       class="">
                        Hindi Movies                    </a>
                                    <a href="?category=Indian+Bangla" 
                       class="">
                        Indian Bangla                    </a>
                                    <a href="?category=Information" 
                       class="">
                        Information                    </a>
                                    <a href="?category=Kids" 
                       class="">
                        Kids                    </a>
                                    <a href="?category=Movies" 
                       class="">
                        Movies                    </a>
                                    <a href="?category=Music" 
                       class="">
                        Music                    </a>
                                    <a href="?category=News" 
                       class="">
                        News                    </a>
                                    <a href="?category=Sports" 
                       class="">
                        Sports                    </a>
                            </div>
        </header>

        <div class="channels-grid">
                                                                    <div class="channel-card" data-name="Zee Bangla">
                        <a href="play.php?id=1">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/5/5f/Zee_Bangla_logo.png" 
                                 alt="Zee Bangla"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Zee Bangla</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Zee Bangla Cinema">
                        <a href="play.php?id=2">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQrrq8WGnJYw7a-0-cVbKSkuw2EKp-IVLAsKA&amp;s" 
                                 alt="Zee Bangla Cinema"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Zee Bangla Cinema</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="24 Ghanta">
                        <a href="play.php?id=3">
                            <img src="https://upload.wikimedia.org/wikipedia/bn/b/b4/%E0%A6%9C%E0%A6%BF_%E0%A7%A8%E0%A7%AA_%E0%A6%98%E0%A6%A3%E0%A7%8D%E0%A6%9F%E0%A6%BE_%E0%A6%8F%E0%A6%B0_%E0%A6%B2%E0%A7%8B%E0%A6%97%E0%A7%8B.png" 
                                 alt="24 Ghanta"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>24 Ghanta</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Zee Marathi">
                        <a href="play.php?id=4">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSi-i5prkgwKrEXGjwZTaK3P-La9vL-0I24Lw&amp;s" 
                                 alt="Zee Marathi"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Zee Marathi</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Zee Talkies">
                        <a href="play.php?id=5">
                            <img src="https://yt3.googleusercontent.com/ytc/AIdro_kaagCCamDXrwbIn-_YYVa93m0J_J-Ahda08hPcRqf8Lw=s900-c-k-c0x00ffffff-no-rj" 
                                 alt="Zee Talkies"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Zee Talkies</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Zee Business">
                        <a href="play.php?id=6">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvV8VWbxLpQTkNX4kU1V5Cprf9mYaiSxluWQ&amp;s" 
                                 alt="Zee Business"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Zee Business</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Shorts TV">
                        <a href="play.php?id=7">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSrb0Dmn99c9WZgM0PuUG3zraPKSv9VjD0ulA&amp;s" 
                                 alt="Shorts TV"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Shorts TV</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Korean Dramas">
                        <a href="play.php?id=8">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR3Gt8W9uh49rkrog1ldtNs5TxDAQOULpFtqQ&amp;s" 
                                 alt="Korean Dramas"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Korean Dramas</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="And TV">
                        <a href="play.php?id=9">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMmzui_TJ7U5d5RiHbqcqh173qA9-h-MFDjw&amp;s" 
                                 alt="And TV"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>And TV</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="And Pictures">
                        <a href="play.php?id=10">
                            <img src="https://jiotvimages.cdn.jio.com/dare_images/images/200/-/And_Pictures.png" 
                                 alt="And Pictures"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>And Pictures</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Zee TV">
                        <a href="play.php?id=11">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/d/d0/Zee_TV-2018.png" 
                                 alt="Zee TV"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Zee TV</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Zee Cinema">
                        <a href="play.php?id=12">
                            <img src="https://astromedia.com.my/wp-content/uploads/2024/01/Zee-Cinema.png" 
                                 alt="Zee Cinema"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Zee Cinema</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Zee Bollywood">
                        <a href="play.php?id=13">
                            <img src="https://www.bizasialive.com/wp-content/uploads/2018/08/zeebollywoodlogoNEW.jpg" 
                                 alt="Zee Bollywood"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Zee Bollywood</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Zee Anmol">
                        <a href="play.php?id=14">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSI0T54ROLDWh7cBfPDZL539n7ZHytYgfxwFA&amp;s" 
                                 alt="Zee Anmol"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Zee Anmol</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="MTV Beats">
                        <a href="play.php?id=16">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwfWrWH1lZo6wIP0_c3V8HKr3XUQfEGAClYw&amp;s" 
                                 alt="MTV Beats"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>MTV Beats</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Zing">
                        <a href="play.php?id=17">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR9hdM2_0ky4nBrT-hJ-vseoOj8goZdzZtQvQ&amp;s" 
                                 alt="Zing"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Zing</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Zoom">
                        <a href="play.php?id=18">
                            <img src="https://yt3.googleusercontent.com/ytc/AIdro_lZEnCMQZz6FfEgDysuhVObO6O972OlqzBOaGwninMVpWk=s900-c-k-c0x00ffffff-no-rj" 
                                 alt="Zoom"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Zoom</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="TLC">
                        <a href="play.php?id=20">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0VgQusmm7733xqNk2wve18H671L5AihvnXI7oZC66pvnqgIIVCukcFkHQyBg9ThM9j98&amp;usqp=CAU" 
                                 alt="TLC"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>TLC</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Discovery Kids">
                        <a href="play.php?id=21">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQGQMAT4d9I9YHwmHAiVxkksWro6YIvffpr4Q&amp;s" 
                                 alt="Discovery Kids"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Discovery Kids</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="HBO_SIGNATURE">
                        <a href="play.php?id=66">
                            <img src="https://images.now-tv.com/shares/channelPreview/img/en_hk/color/ch114_425_305" 
                                 alt="HBO_SIGNATURE"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>HBO_SIGNATURE</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="MORE_MAX">
                        <a href="play.php?id=68">
                            <img src="https://static.wikia.nocookie.net/logosfake/images/4/4d/MoreMax_logo.svg/revision/latest?cb=20170825133912" 
                                 alt="MORE_MAX"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>MORE_MAX</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="MOVIE_MAX">
                        <a href="play.php?id=69">
                            <img src="https://archive.org/download/CinemaxMoviemax/cinemax%20moviemax.png" 
                                 alt="MOVIE_MAX"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>MOVIE_MAX</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="ACTION_MAX">
                        <a href="play.php?id=70">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/f/fe/Action_max_logo.png" 
                                 alt="ACTION_MAX"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>ACTION_MAX</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="CINEMAX_HD">
                        <a href="play.php?id=71">
                            <img src="https://banner2.cleanpng.com/20180601/qaa/avo1zewlu.webp" 
                                 alt="CINEMAX_HD"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>CINEMAX_HD</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="MGM_DRIVE_IN">
                        <a href="play.php?id=73">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRRtSM9m8cVDpUy-6GcDatbfJqNRAzQxoqkQg&amp;s" 
                                 alt="MGM_DRIVE_IN"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>MGM_DRIVE_IN</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="TNT1">
                        <a href="play.php?id=201">
                            <img src="https://media.info/l/o/1/1539.1690027797.png" 
                                 alt="TNT1"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>TNT1</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="TNT2">
                        <a href="play.php?id=202">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRS4R1CjAeCjmAehJn4g7dzScZj5FwS7daoSQ&amp;s" 
                                 alt="TNT2"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>TNT2</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="TNT3">
                        <a href="play.php?id=203">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_8RQE49umXULt1pTKGm5pvD7mIIZ6D_GuBg&amp;s" 
                                 alt="TNT3"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>TNT3</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="TNT4">
                        <a href="play.php?id=204">
                            <img src="https://upload.wikimedia.org/wikipedia/en/6/6b/TNT_Sports_4_logo.png" 
                                 alt="TNT4"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>TNT4</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="USA Network">
                        <a href="play.php?id=205">
                            <img src="https://graphicdesignfall16.wordpress.com/wp-content/uploads/2016/10/usa-network-logo1.jpg?w=430" 
                                 alt="USA Network"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>USA Network</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Fancode LIVE">
                        <a href="play.php?id=207">
                            <img src="https://images.sftcdn.net/images/t_app-icon-m/p/d6182af5-1c81-458d-8610-7dd2a1dd0495/1909126832/fancode-live-cricket-scores-logo" 
                                 alt="Fancode LIVE"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Fancode LIVE</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Willow Sports Live">
                        <a href="play.php?id=208">
                            <img src="https://www.trillertv.com/thumbs/o/picon/100/1292_200x200.jpg" 
                                 alt="Willow Sports Live"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Willow Sports Live</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="NFL">
                        <a href="play.php?id=216">
                            <img src="https://upload.wikimedia.org/wikipedia/en/thumb/a/a2/National_Football_League_logo.svg/640px-National_Football_League_logo.svg.png" 
                                 alt="NFL"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>NFL</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="NFL_2">
                        <a href="play.php?id=217">
                            <img src="https://upload.wikimedia.org/wikipedia/en/thumb/8/8f/NFL_Network_logo.svg/640px-NFL_Network_logo.svg.png" 
                                 alt="NFL_2"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>NFL_2</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="NBC_SPORTS">
                        <a href="play.php?id=218">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/77/NBC_Sports_Network_logo.svg/640px-NBC_Sports_Network_logo.svg.png" 
                                 alt="NBC_SPORTS"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>NBC_SPORTS</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="PREMIER_LEAGUE_TV">
                        <a href="play.php?id=219">
                            <img src="https://upload.wikimedia.org/wikipedia/en/thumb/f/f2/Premier_League_Logo.svg/1200px-Premier_League_Logo.svg.png" 
                                 alt="PREMIER_LEAGUE_TV"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>PREMIER_LEAGUE_TV</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="SSC1">
                        <a href="play.php?id=220">
                            <img src="https://i.imgur.com/dM7GQXG.png" 
                                 alt="SSC1"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>SSC1</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="SSC2">
                        <a href="play.php?id=221">
                            <img src="https://www.lyngsat.com/logo/tv/ss/ssc-2-sa.png" 
                                 alt="SSC2"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>SSC2</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="SSC3">
                        <a href="play.php?id=222">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQGeFtCWbOI6sABfwuPeNZHOa5136WYG5zZjg&amp;s" 
                                 alt="SSC3"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>SSC3</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="SSC4">
                        <a href="play.php?id=223">
                            <img src="https://www.lyngsat.com/logo/tv/ss/ssc-4-sa.png" 
                                 alt="SSC4"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>SSC4</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="SSC5">
                        <a href="play.php?id=224">
                            <img src="https://www.lyngsat.com/logo/tv/ss/ssc-5-sa.png" 
                                 alt="SSC5"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>SSC5</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="SSC_EXTRA1">
                        <a href="play.php?id=225">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSUHfhpv1NKHwQ46dx64sxjCPa4MzE6iClCbA&amp;s" 
                                 alt="SSC_EXTRA1"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>SSC_EXTRA1</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="DAZN_1_ES">
                        <a href="play.php?id=227">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/49/DAZN_1.svg/800px-DAZN_1.svg.png" 
                                 alt="DAZN_1_ES"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>DAZN_1_ES</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="DAZN_2_ES">
                        <a href="play.php?id=228">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/76/DAZN_2.svg/800px-DAZN_2.svg.png" 
                                 alt="DAZN_2_ES"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>DAZN_2_ES</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="EUROSPORT_1_ES">
                        <a href="play.php?id=229">
                            <img src="https://w7.pngwing.com/pngs/350/883/png-transparent-eurosport-1-eurosport-2-television-channel-1-euro-television-blue-angle.png" 
                                 alt="EUROSPORT_1_ES"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>EUROSPORT_1_ES</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="EUROSPORT_2_ES">
                        <a href="play.php?id=230">
                            <img src="https://e7.pngegg.com/pngimages/327/493/png-clipart-eurosport-1-television-channel-logo-eurosport-2-others-miscellaneous-television.png" 
                                 alt="EUROSPORT_2_ES"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>EUROSPORT_2_ES</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="NBC_USA">
                        <a href="play.php?id=231">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/NBC_logo_2022_%28vertical%29.svg/800px-NBC_logo_2022_%28vertical%29.svg.png" 
                                 alt="NBC_USA"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>NBC_USA</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="FUBO_SPORTS">
                        <a href="play.php?id=232">
                            <img src="https://images.fubo.tv/station_logos/fubo-sports23_c.png" 
                                 alt="FUBO_SPORTS"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>FUBO_SPORTS</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="FUBO_SPORTS_2">
                        <a href="play.php?id=233">
                            <img src="https://images.fubo.tv/station_logos/Fubo_Sports_2_c.png" 
                                 alt="FUBO_SPORTS_2"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>FUBO_SPORTS_2</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Tsports 2 (BD)">
                        <a href="play.php?id=1739822079085">
                            <img src="https://image.tsports.com/images/mobile_thumbnail/1719127158-LIVE.jpg" 
                                 alt="Tsports 2 (BD)"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Tsports 2 (BD)</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Sky Sports LL">
                        <a href="play.php?id=1739824275425">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQVuqd8LpANErjfyHMVvz7EN81q9oiUzGlK0Q&amp;s" 
                                 alt="Sky Sports LL"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Sky Sports LL</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Bein SP 2">
                        <a href="play.php?id=1739824070195">
                            <img src="https://logowik.com/content/uploads/images/bein-sports-25584.logowik.com.webp" 
                                 alt="Bein SP 2"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Bein SP 2</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Zee Anmol Cinema">
                        <a href="play.php?id=15">
                            <img src="https://multireach.in/wp-content/uploads/2020/10/zeeanmolcinema-1.jpg" 
                                 alt="Zee Anmol Cinema"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Zee Anmol Cinema</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="SSC_EXTRA2">
                        <a href="play.php?id=226">
                            <img src="https://live.multies.net/wp-content/uploads/2022/05/SSC-Extra-2.png" 
                                 alt="SSC_EXTRA2"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>SSC_EXTRA2</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="MGM_HITS">
                        <a href="play.php?id=74">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/28/MGM%2B_Hits_2023.svg/2560px-MGM%2B_Hits_2023.svg.png" 
                                 alt="MGM_HITS"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>MGM_HITS</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="HBO_2">
                        <a href="play.php?id=65">
                            <img src="https://logowik.com/content/uploads/images/hbo-21940.logowik.com.webp" 
                                 alt="HBO_2"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>HBO_2</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="HBO_COMEDY">
                        <a href="play.php?id=67">
                            <img src="https://c3.klipartz.com/pngpicture/151/793/sticker-png-tv-channel-icons-pack-hbo-comedy-color-thumbnail.png" 
                                 alt="HBO_COMEDY"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>HBO_COMEDY</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="HBO_FAMILY">
                        <a href="play.php?id=64">
                            <img src="https://w7.pngwing.com/pngs/534/400/png-transparent-logo-hbo-brasil-hbo-family-hbo-2-design-text-logo-family-thumbnail.png" 
                                 alt="HBO_FAMILY"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>HBO_FAMILY</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="SCREENPIX_ACTION">
                        <a href="play.php?id=72">
                            <img src="https://static.wikia.nocookie.net/logopedia/images/2/27/ScreenPix_Action.png/revision/latest/scale-to-width-down/1200?cb=20221116050229" 
                                 alt="SCREENPIX_ACTION"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>SCREENPIX_ACTION</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="NBC GOLF">
                        <a href="play.php?id=705">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSurc7jgzeg9uvKKiA8PIulAVJyWsKRN-tUlw&amp;s" 
                                 alt="NBC GOLF"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>NBC GOLF</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Tennis Channel">
                        <a href="play.php?id=706">
                            <img src="https://cdn6.aptoide.com/imgs/f/b/6/fb6e1c4987eae68aa7e5317b75e6e06f_icon.png" 
                                 alt="Tennis Channel"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Tennis Channel</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="UFC">
                        <a href="play.php?id=707">
                            <img src="https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcS0nQSEXtDaiycpLDoqPUqdH_z7s9esrq6QuEqpFFXCohoeYmvWjxEfkm0PRZnrcJHEf-AwIHxjGzfdyGzOrJXScdZ0-B59nRXjc969Yp0" 
                                 alt="UFC"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>UFC</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Onechampion Ship">
                        <a href="play.php?id=708">
                            <img src="https://mma.prnewswire.com/media/1190969/ONE_Championship_Logo.jpg?w=300" 
                                 alt="Onechampion Ship"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Onechampion Ship</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="MUTV">
                        <a href="play.php?id=710">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS92iMrUEgX6qTagtptWHtKyga5J7vnznv-6g&amp;s" 
                                 alt="MUTV"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>MUTV</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Realmadrid TV">
                        <a href="play.php?id=711">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5GaQcvncK3h-LvMI_qsjLiCjdfW4o7rNkYw&amp;s" 
                                 alt="Realmadrid TV"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Realmadrid TV</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="FOX Sport 1">
                        <a href="play.php?id=714">
                            <img src="https://logowik.com/content/uploads/images/fox-sports3529.jpg" 
                                 alt="FOX Sport 1"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>FOX Sport 1</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="FOX Sport 2">
                        <a href="play.php?id=715">
                            <img src="https://logowik.com/content/uploads/images/fox-sports3529.jpg" 
                                 alt="FOX Sport 2"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>FOX Sport 2</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="FOX Sport 3">
                        <a href="play.php?id=716">
                            <img src="https://logowik.com/content/uploads/images/fox-sports3529.jpg" 
                                 alt="FOX Sport 3"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>FOX Sport 3</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="ESPN 1">
                        <a href="play.php?id=717">
                            <img src="https://a1.espncdn.com/combiner/i?img=%2Fi%2Fespn%2Fespn_logos%2Fespn_red.png" 
                                 alt="ESPN 1"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>ESPN 1</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="ESPN 2">
                        <a href="play.php?id=718">
                            <img src="https://a1.espncdn.com/combiner/i?img=%2Fi%2Fespn%2Fespn_logos%2Fespn_red.png" 
                                 alt="ESPN 2"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>ESPN 2</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="ESPN 3">
                        <a href="play.php?id=719">
                            <img src="https://a1.espncdn.com/combiner/i?img=%2Fi%2Fespn%2Fespn_logos%2Fespn_red.png" 
                                 alt="ESPN 3"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>ESPN 3</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="ESPN 4">
                        <a href="play.php?id=720">
                            <img src="https://a1.espncdn.com/combiner/i?img=%2Fi%2Fespn%2Fespn_logos%2Fespn_red.png" 
                                 alt="ESPN 4"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>ESPN 4</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="ESPN 5">
                        <a href="play.php?id=721">
                            <img src="https://a1.espncdn.com/combiner/i?img=%2Fi%2Fespn%2Fespn_logos%2Fespn_red.png" 
                                 alt="ESPN 5"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>ESPN 5</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="ESPN 6">
                        <a href="play.php?id=722">
                            <img src="https://a1.espncdn.com/combiner/i?img=%2Fi%2Fespn%2Fespn_logos%2Fespn_red.png" 
                                 alt="ESPN 6"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>ESPN 6</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="ESPN 7">
                        <a href="play.php?id=723">
                            <img src="https://a1.espncdn.com/combiner/i?img=%2Fi%2Fespn%2Fespn_logos%2Fespn_red.png" 
                                 alt="ESPN 7"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>ESPN 7</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Dhabi Sports 1">
                        <a href="play.php?id=724">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQ0xYv5yIHJ99ClwUGHCO-RX10tClHaZ2WgA&amp;s" 
                                 alt="Dhabi Sports 1"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Dhabi Sports 1</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Dhabi Sports 2">
                        <a href="play.php?id=725">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQ0xYv5yIHJ99ClwUGHCO-RX10tClHaZ2WgA&amp;s" 
                                 alt="Dhabi Sports 2"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Dhabi Sports 2</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Red Bull TV">
                        <a href="play.php?id=712">
                            <img src="https://images.ctfassets.net/9wbsp34au6cz/3MahTdkrffTFVnuawblwdI/ea27b13f6bd84eaab03f5f298bce672d/RBTV_Logo_single_pix_hor_RGB.png?w=350&amp;q=90" 
                                 alt="Red Bull TV"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Red Bull TV</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="NBC">
                        <a href="play.php?id=701">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/NBC_logo.svg/1200px-NBC_logo.svg.png" 
                                 alt="NBC"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>NBC</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="One SPORT">
                        <a href="play.php?id=713">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/One_Sports_logo.svg/1200px-One_Sports_logo.svg.png" 
                                 alt="One SPORT"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>One SPORT</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Universo East">
                        <a href="play.php?id=702">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Universo_2017.svg/1200px-Universo_2017.svg.png" 
                                 alt="Universo East"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Universo East</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="PPTV HD36">
                        <a href="play.php?id=703">
                            <img src="https://play-lh.googleusercontent.com/clhMtBU3QtreaoCWrETPNIAVjbrlgzsSzOLaspaZ2kmd_cKCgIkSggz07lBsmaGLIka0" 
                                 alt="PPTV HD36"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>PPTV HD36</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Bein SP 1">
                        <a href="play.php?id=1740816990864">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWdcDw40yx8_J4WDXOwbLZbvEwG4Pdg4J1wGVSY5mPrnzlVjSs71XtgIoL03D28rdlToM&amp;usqp=CAU" 
                                 alt="Bein SP 1"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Bein SP 1</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Ten Cricket">
                        <a href="play.php?id=1740817154994">
                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRLMhVJFXkNYK7trsuhRe58ZK1-pQLUhD3T6w&amp;s" 
                                 alt="Ten Cricket"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Ten Cricket</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Geo Super Live">
                        <a href="play.php?id=1740817307371">
                            <img src="https://play-lh.googleusercontent.com/u7vR1z3UhqPPbd315kLIaZCPAxY8uPQdLXKnyYEAKcJfjAcwoUvJRNyDCkJ9p-uxlNmy" 
                                 alt="Geo Super Live"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Geo Super Live</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="Prime EN">
                        <a href="play.php?id=1739958612523">
                            <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcR0eMth9_eP51Y1F5BsX-nzqKCWpEP0mdrT27WKv--4jCZqMSGBK_Ymr1X0UdhzyisnZfqf-TmSHaxmhE3uSdYlMWeZ179F8jhRUx93xqg" 
                                 alt="Prime EN"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>Prime EN</h3>
                        </a>
                    </div>
                                                        <div class="channel-card" data-name="WWE SMACKDOWN">
                        <a href="play.php?id=709">
                            <img src="https://upload.wikimedia.org/wikipedia/en/8/8c/WWE_Network_logo.jpeg" 
                                 alt="WWE SMACKDOWN"
                                 onerror="this.src='assets/default-logo.png'">
                            <h3>WWE SMACKDOWN</h3>
                        </a>
                    </div>
                                    </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const searchInput = document.getElementById('searchInput');
        const cards = document.getElementsByClassName('channel-card');
        
        function performSearch() {
            const searchTerm = searchInput.value.toLowerCase().trim();
            
            Array.from(cards).forEach(card => {
                const channelName = card.dataset.name.toLowerCase();
                card.style.display = channelName.includes(searchTerm) ? 'block' : 'none';
            });
        }

        // Real-time search events
        searchInput.addEventListener('input', performSearch);
        searchInput.addEventListener('paste', performSearch);
        searchInput.addEventListener('search', performSearch);
    });
    </script>

    <style>
    /* Add these styles to your existing CSS */
    .channel-card {
        transition: opacity 0.2s ease-in-out;
    }

    #searchInput {
        width: 100%;
        max-width: 300px;
        padding: 8px 12px;
        border: 2px solid #ddd;
        border-radius: 6px;
        font-size: 16px;
        transition: all 0.3s ease;
    }

    #searchInput:focus {
        border-color: #007bff;
        box-shadow: 0 0 5px rgba(0,123,255,0.3);
        outline: none;
    }
    </style>
</body>
</html>